if (!require(keras)) install.packages("keras")
if (!require(tensorflow)) install.packages("tensorflow")

# Load libraries
library(keras)
library(tensorflow)

# Load the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()

# Split into training and test sets
X_train <- fashion_mnist$train$x
y_train <- fashion_mnist$train$y
X_test <- fashion_mnist$test$x
y_test <- fashion_mnist$test$y

# Reshape the data for the CNN (images need to be 4D arrays)
X_train <- array_reshape(X_train, c(nrow(X_train), 28, 28, 1))
X_test <- array_reshape(X_test, c(nrow(X_test), 28, 28, 1))

# Normalize pixel values to range [0, 1]
X_train <- X_train / 255
X_test <- X_test / 255

# One-hot encode the labels
y_train <- to_categorical(y_train, 10)
y_test <- to_categorical(y_test, 10)

# Initialize the model
model <- keras_model_sequential()

# Add layers to the model
model %>%
  # Convolutional layer 1
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  
  # Convolutional layer 2
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  
  # Flatten the data for dense layers
  layer_flatten() %>%
  
  # Fully connected layers
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model on the training data
history <- model %>% fit(
  X_train, y_train,
  epochs = 10,
  batch_size = 32,
  validation_split = 0.2
)

# Evaluate the model on the test data
metrics <- model %>% evaluate(X_test, y_test)
cat("Test Loss:", metrics[[1]], "\n")
cat("Test Accuracy:", metrics[[2]], "\n")

# Predict on test data
predictions <- model %>% predict(X_test)

# Get predicted class labels for two images
predicted_labels <- apply(predictions[1:2, ], 1, which.max) - 1  # Subtract 1 to match original label encoding

# Print the predictions for the first two images
cat("Predictions for first two images:\n")
print(predicted_labels)

# Visualize the first two images with their predicted labels
par(mfrow = c(1, 2))  # Arrange plots in a row
for (i in 1:2) {
  image(1:28, 1:28, t(apply(X_test[i, , , 1], 2, rev)), col = gray.colors(256),
        main = paste("Predicted:", predicted_labels[i]), xlab = "", ylab = "")
}